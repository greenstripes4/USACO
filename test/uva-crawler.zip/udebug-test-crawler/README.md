# udebugcli
Utility CLI for automatically testing solutions of competitive programming online judges.
