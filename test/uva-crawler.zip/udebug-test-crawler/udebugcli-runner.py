#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from udebugcli.udebugcli import main


if __name__ == '__main__':
    main()
