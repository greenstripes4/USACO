# -*- coding: utf-8 -*-


from .udebugcli import main
main()
