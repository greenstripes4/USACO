# https://www.thepythoncode.com/article/extracting-and-submitting-web-page-forms-in-python

import requests
import json
import os
from requests_html import HTMLSession
from urllib.parse import urljoin
from bs4 import BeautifulSoup

PREFIX = "https://www.udebug.com/"
# initialize an HTTP session
session = HTMLSession()


# Get test input ids from uDebug page like "https://www.udebug.com/UVa/10032"
def get_test_ids(url):
    # GET request
    response = session.get(url)
    # for javascript driven website
    # res.html.render()
    soup_obj = BeautifulSoup(response.html.html, "html.parser")
    tests = soup_obj.find_all("a", class_="input_desc")
    id_set = set()
    for test in tests:
        id_set.add(test["data-id"])
    return list(id_set)


# Get test input data from 'https://www.udebug.com/udebug-custom-get-selected-input-ajax'
def get_test_data(test_id):
    ajax_url = 'https://www.udebug.com/udebug-custom-get-selected-input-ajax'
    post_payload = {'input_nid': test_id}
    x = requests.post(ajax_url, data=post_payload)
    content = BeautifulSoup(x.content, "html.parser")
    input_json = json.loads(content.text)
    return input_json['input_value']


def get_all_forms(url):
    """Returns all form tags found on a web page's `url` """
    # GET request
    res = session.get(url)
    # for javascript driven website
    # res.html.render()
    soup = BeautifulSoup(res.html.html, "html.parser")
    return soup.find_all("form")


def get_form_details(form):
    """Returns the HTML details of a form,
    including action, method and list of form controls (inputs, etc)"""
    details = {}
    # id
    id = form.attrs.get("id")
    # get the form action (requested URL)
    action = form.attrs.get("action").lower()
    # get the form method (POST, GET, DELETE, etc)
    # if not specified, GET is the default in HTML
    method = form.attrs.get("method", "get").lower()
    # get all form inputs
    inputs = []
    for input_tag in form.find_all("input"):
        # get type of input form control
        input_type = input_tag.attrs.get("type", "text")
        # get name attribute
        input_name = input_tag.attrs.get("name")
        # get the default value of that input tag
        input_value = input_tag.attrs.get("value", "")
        # add everything to that list
        inputs.append({"type": input_type, "name": input_name, "value": input_value})

    # get all form textareas
    textareas = []
    for input_tag in form.find_all("textarea"):
        # get id of input text control
        input_id = input_tag.attrs.get("id")
        # get name attribute
        input_name = input_tag.attrs.get("name")
        # get the default value of that input tag
        input_value = input_tag.attrs.get("value", "")
        # add everything to that list
        textareas.append({"id": input_id, "name": input_name, "value": input_value})
    # put everything to the resulting dictionary
    details["id"] = id
    details["action"] = action
    details["method"] = method
    details["inputs"] = inputs
    details["textareas"] = textareas
    return details


# Generate the test output from uDebug
def get_test_output(target_url, test_input):
    # get the second form
    second_form = get_all_forms(target_url)[1]
    form_details = get_form_details(second_form)
    # the data body we want to submit
    data = {}
    for input_tag in form_details["inputs"]:
        if input_tag["type"] == "hidden":
            # if it's hidden, use the default value
            data[input_tag["name"]] = input_tag["value"]
        elif input_tag["type"] != "submit":
            # all others except submit, prompt the user to set it
            # value = input(f"Enter the value of the field '{input_tag['name']}' (type: {input_tag['type']}): ")
            # data[input_tag["name"]] = value
            data[input_tag["name"]] = input_tag["value"]
    for input_tag in form_details["textareas"]:
        data[input_tag["name"]] = test_input

    # join the url with the action (form request URL)
    url = urljoin(target_url, form_details["action"])

    if form_details["method"] == "post":
        res = session.post(url, data=data)
    elif form_details["method"] == "get":
        res = session.get(url, params=data)

    soup = BeautifulSoup(res.html.html, "html.parser")
    output = soup.find("textarea", {"id":"edit-output-data"})

    return output.text


# Crawl test data from uDebug and write to local files for UVA problems
def crawl_test_data(oj_alias, problem_id):
    target_url = PREFIX + oj_alias + "/" + problem_id
    local_folder = "./" + oj_alias + problem_id
    # If folder doesn't exist, then create it.
    if not os.path.isdir(local_folder):
        os.makedirs(local_folder)

    test_ids = get_test_ids(target_url)
    for test_id in test_ids:
        input_file = local_folder + "/" + test_id + ".in"
        input_data = get_test_data(test_id)
        text_file = open(input_file, "wt")
        text_file.write(input_data)
        text_file.close()
        output_file = local_folder + "/" + test_id + ".out"
        output_data = get_test_output(target_url, input_data)
        text_file = open(output_file, "wt")
        text_file.write(output_data)
        text_file.close()


for problem in range(170, 1761):
    print("working on " + str(problem))
    crawl_test_data("UVa", str(problem))
"""
# get all form tags
forms = get_all_forms(URL)
# iteratte over forms
for i, form in enumerate(forms, start=1):
    form_details = get_form_details(form)
    print("="*50, f"form #{i}", "="*50)
    print(form_details)
"""
